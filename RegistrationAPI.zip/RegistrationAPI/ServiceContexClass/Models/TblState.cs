﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ServiceContexClass.Models
{
    public partial class TblState
    {
        public int Id { get; set; }
        public string StateName { get; set; }
    }
}
